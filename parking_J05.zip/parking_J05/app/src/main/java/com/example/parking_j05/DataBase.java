package com.example.parking_j05;


import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DataBase {

    private final String userName = "admin";
    private final String password = "transportlab";

    private static Connection conn = null;
    private static Statement st = null;
    private List<int []> plan = null;
    private boolean connected = false;
    private MainActivity mainActivity;

    public DataBase(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    private String getConnectionUrl() {
        String url = "jdbc:mysql://";
        String serverName = "liparkdb.cvuwuyaiiqgl.ap-southeast-2.rds.amazonaws.com";
        String portNumber = "3306/";
        String databaseName = "LiDAR_Parking";
        return url + serverName + ":" + portNumber + databaseName;
    }

    public List<int []> getPlan(){
        return this.plan;
    }

    public boolean checkConnected(){
        return this.connected;
    }

    public void linkDatabase() {
        new Thread(() -> {
            try {
                Log.i("msg", "connect");
                Class.forName("com.mysql.jdbc.Driver");

                conn = DriverManager.getConnection(getConnectionUrl(), userName, password);

                if (conn != null) {
                    st = conn.createStatement();

                    Log.i("msg", "Successfully connected");
                } else {
                    Log.i("msg", "connect failed");
                }

            } catch (ClassNotFoundException e) {
                Log.i("msg", "Class not found");
                e.printStackTrace();
            } catch (SQLException e) {
                Log.i("msg", "SQL Exception: " + e.getMessage());
            } catch (Exception e) {
                Log.i("error", e.getMessage());
                e.printStackTrace();
            }

            while(true) {

                try {
                    String sql = "select * from park_2D";
                    ResultSet res = st.executeQuery(sql);
                    plan = new ArrayList<>();

                    while (res.next()) {
                        int[] park = new int[12];
                        park[0] = res.getInt("Id");
                        park[1] = res.getInt("TL_x");
                        park[2] = res.getInt("TL_y");
                        park[3] = res.getInt("TR_x");
                        park[4] = res.getInt("TR_y");
                        park[5] = res.getInt("BR_x");
                        park[6] = res.getInt("BR_y");
                        park[7] = res.getInt("BL_x");
                        park[8] = res.getInt("BL_y");
                        park[9] = res.getInt("width");
                        park[10] = res.getInt("height");
                        park[11] = res.getInt("status");

                        plan.add(park);
                    }

                    this.mainActivity.draw();

                } catch (Exception e) {

                    Log.i("check", "no");
                    Log.d("msg", "SQL Exception: " + e.getMessage());
                }

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }).start();

    }

}