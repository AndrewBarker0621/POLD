package com.example.parking_j05;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;

import java.util.List;

public class MyView extends View {

    private List<int[]> plan;
    private boolean connected = false;

    public MyView(Context context) {
        super(context);
    }

    public void myRefresh(List<int[]> plan){
        this.plan = plan;
        this.connected = true;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Paint paintRed = new Paint();
        paintRed.setColor(Color.RED);
        paintRed.setStyle(Paint.Style.FILL);
        paintRed.setStrokeWidth(5);

        Paint paintGreen = new Paint();
        paintGreen.setColor(Color.GREEN);
        paintGreen.setStyle(Paint.Style.FILL);
        paintGreen.setStrokeWidth(5);

        if(this.connected){
            for(int i = 0; i < plan.size(); i++){

                Paint paint = null;

                if(plan.get(i)[11] == 0){
                    paint = paintGreen;
                } else{
                    paint = paintRed;
                }
                canvas.drawLine(plan.get(i)[1] + 5, plan.get(i)[2] + 200, plan.get(i)[3] + 5, plan.get(i)[4] + 200, paint);
                canvas.drawLine(plan.get(i)[3] + 5, plan.get(i)[4] + 200, plan.get(i)[5] + 5, plan.get(i)[6] + 200, paint);
                canvas.drawLine(plan.get(i)[5] + 5, plan.get(i)[6] + 200, plan.get(i)[7] + 5, plan.get(i)[8] + 200, paint);
                canvas.drawLine(plan.get(i)[7] + 5, plan.get(i)[8] + 200, plan.get(i)[1] + 5, plan.get(i)[2] + 200, paint);
            }

        }
    }
}
