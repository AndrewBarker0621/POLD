import pymysql
from datetime import datetime


class Mysql(object):
    def __init__(self):
        try:
            self.conn = pymysql.connect(host='liparkdb.cvuwuyaiiqgl.ap-southeast-2.rds.amazonaws.com', user='admin',
                                        password='transportlab', database='LiDAR_Parking', charset='utf8')
            print("Succeed")
        except:
            print("Failed")

        self.table_list = []

    def getItems(self):
        currentDateAndTime = datetime.now()
        currentTime = currentDateAndTime.strftime("%S")
        count = int(currentTime) % 2
        return count

    def getPlan(self):
        cursor = self.conn.cursor()

        sql = 'select * from park_2D'
        cursor.execute(sql)

        results = cursor.fetchall()
        self.table_list = []
        for r in results:
            self.table_list.append(list(r))
        cursor.close()

        return list(self.table_list)

