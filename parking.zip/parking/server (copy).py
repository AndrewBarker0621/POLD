from flask import Flask,request
from flask import render_template
from mysql import Mysql
from flask_script import Manager
from livereload import Server
from datetime import timedelta


app = Flask(__name__)
manager = Manager(app)

@app.route('/lidar/', methods = ['GET'])
def name():
    # page = request.args.get('page')
    # if not page or int(page) == 0:
    #     page = 1
    # keyword = request.args.get('keyword')
    # page_range = range(int(page) - 3, int(page) + 2)
    # if int(page) < 4:
    #     page_range = range(1, int(page) + 4)
    db = Mysql()
    items = db.getItems()
    return render_template('lidar.html', items = items)
    # return render_template('lidar.html', items = items, page = int(page), prange = page_range)

@manager.command
def dev():
    live_server = Server(app.wsgi_app)
    live_server.watch('**/*.*')
    live_server.serve(open_url = True)

if __name__ == '__main__':
    app.run(app.run(debug = True, port = 2008, host = '0.0.0.0'))
    manager.run()