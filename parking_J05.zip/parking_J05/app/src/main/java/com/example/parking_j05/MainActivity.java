package com.example.parking_j05;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.sql.SQLException;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    private DataBase db;
    private MyView view;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        view = new MyView(this);
        textView = findViewById(R.id.textView2);
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.forever);
        frameLayout.addView(view);

        db = new DataBase(this);
        db.linkDatabase();
    }

    public void draw(){
        List<int[]> plan = db.getPlan();
        view.myRefresh(plan);
    }

    public void availability(int ava){
        String sAvaFormat = getResources().getString(R.string.ava);
        String sFinalAva = String.format(sAvaFormat, ava);
        textView.setText(sFinalAva);
    }
}