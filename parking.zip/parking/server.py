import time

from flask import Flask, request
from flask import render_template

from flask_script import Manager
from livereload import Server

from mysql import Mysql

app = Flask(__name__)
manager = Manager(app)


@app.route('/lidar/', methods = ['GET'])
def name():
    db = Mysql()
    items = db.getItems()
    return render_template('lidar.html', items = items)

@manager.command
def dev():
    live_server = Server(app.wsgi_app)
    live_server.watch('**/*.*')
    live_server.serve(open_url = True)

if __name__ == '__main__':
    app.run(app.run(debug = True, port = 2008, host = '0.0.0.0'))
    manager.run()

# http://3.25.60.79:2008/lidar
