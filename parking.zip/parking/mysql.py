import pymysql

class Mysql(object):
    def __init__(self):
        try:
            self.conn = pymysql.connect(host = 'liparkdb.cvuwuyaiiqgl.ap-southeast-2.rds.amazonaws.com', user='admin', password = 'transportlab', database = 'LiDAR_Parking', charset = 'utf8')
            self.cursor = self.conn.cursor()  
            print("Succeed")
        except:
            print("Failed")

    def getItems(self):
        sql = "select status from park_2D where Id = 1"
        self.cursor.execute(sql)
        DATA = self.cursor.fetchall()
        status = list(DATA)
        return status[0][0]